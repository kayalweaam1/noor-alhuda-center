// Firebase removed - using custom OTP system instead
// This file is kept for compatibility but not used
export const auth = null;
export default null;

